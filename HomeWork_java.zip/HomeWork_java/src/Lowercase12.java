import java.util.Scanner;

public class Lowercase12 {
    public static void main(String[] args){


        System.out.println("LowerCase ALPHABET....");

        //print lowercase alphbet
        char Lowalpha;
        for (Lowalpha = 'a'; Lowalpha <= 'z'; Lowalpha++)
        {
            System.out.println(Lowalpha);

        }
        System.out.println("_______________");
        //print uppercase alphabet
        System.out.println("Uppercase Alphabet");
        char Upperalpha;
        for (Lowalpha = 'A'; Lowalpha <='Z'; Lowalpha++)
        {
            System.out.println(Lowalpha);
        }

    }
}
